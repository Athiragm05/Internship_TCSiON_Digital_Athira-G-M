package Agent_front_end;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Functonality_checking_Agent {

	public static void main(String[] args) throws Exception {
		
		System.setProperty("webdriver.chrome.driver", "D:\\Software Testing\\Selenium chrome\\Chrome Driver\\chromedriver-win32\\chromedriver.exe");		
		WebDriver driver = new ChromeDriver();

		driver.get("https://phptravels.net");
		Thread.sleep(2000);
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//strong[contains(text(),'Account')]")).click();
		WebElement login=driver.findElement(By.cssSelector("#navbarSupportedContent > div.nav-item--right > ul > li:nth-child(3) > ul > li:nth-child(1) > a"));
		login.click();
		Thread.sleep(2000);
		WebElement usernamevalid=driver.findElement(By.xpath("//input[@name='email']"));
		usernamevalid.sendKeys("agent@phptravels.com");
		WebElement password=driver.findElement(By.xpath("//input[@name='password']"));
		password.sendKeys("demoagent");
		driver.findElement(By.xpath("//button[@id='submitBTN']")).click();
		Thread.sleep(2000);
		WebElement MyBookings=driver.findElement(By.cssSelector("#fadein > div:nth-child(5) > div > div > div:nth-child(2) > ul > li:nth-child(2) > a"));
		MyBookings.click();
		WebElement Profile=driver.findElement(By.cssSelector("#fadein > div:nth-child(5) > div > div > div:nth-child(2) > ul > li:nth-child(3) > a"));
		Profile.click();
		WebElement Logout=driver.findElement(By.cssSelector("#fadein > div:nth-child(5) > div > div > div:nth-child(2) > ul > li:nth-child(4) > a"));
		Logout.click();

	}

}
