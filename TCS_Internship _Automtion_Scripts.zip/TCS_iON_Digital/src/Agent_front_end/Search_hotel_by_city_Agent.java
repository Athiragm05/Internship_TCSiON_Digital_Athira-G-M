package Agent_front_end;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Search_hotel_by_city_Agent {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "D:\\Software Testing\\Selenium chrome\\Chrome Driver\\chromedriver-win32\\chromedriver.exe");		
		WebDriver driver = new ChromeDriver();

		driver.get("https://phptravels.net");
		Thread.sleep(2000);
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//strong[contains(text(),'Account')]")).click();
		WebElement login=driver.findElement(By.cssSelector("#navbarSupportedContent > div.nav-item--right > ul > li:nth-child(3) > ul > li:nth-child(1) > a"));
		login.click();
		Thread.sleep(2000);
		WebElement usernamevalid=driver.findElement(By.xpath("//input[@name='email']"));
		usernamevalid.sendKeys("agent@phptravels.com");
		WebElement password=driver.findElement(By.xpath("//input[@name='password']"));
		password.sendKeys("demoagent");
		driver.findElement(By.xpath("//button[@id='submitBTN']")).click();
		Thread.sleep(2000);
		WebElement Hotels=driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/div[1]/ul/li[1]/a"));
		Hotels.click();
		WebElement Selectbycity=driver.findElement(By.xpath("/html/body/section[1]/section/div/div/div/form/div/div[1]/div[1]/span/span[1]/span/span[1]"));
		Selectbycity.click();
		WebElement Cityname=driver.findElement(By.cssSelector("#select2-hotels_city-results > div > div:nth-child(2)"));
		Cityname.click();
		driver.findElement(By.cssSelector("#hotels-search > div > div.col-md-1 > button")).click();
		

	}

}
