package Admin_Back_End;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login_Admin {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "D:\\Software Testing\\Selenium chrome\\Chrome Driver\\chromedriver-win32\\chromedriver.exe");		
		WebDriver driver = new ChromeDriver();

		driver.get("https://phptravels.net/admin");
		Thread.sleep(2000);
		driver.manage().window().maximize();
		Thread.sleep(2000);
		WebElement usernameinvalid=driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div[1]/form/div[1]/div/input"));
		usernameinvalid.sendKeys("adm@phptravels.com");
		WebElement passwordinvalid=driver.findElement(By.xpath("//input[@name='password']"));
		passwordinvalid.sendKeys("demoadmin");
		driver.findElement(By.xpath("//button[@id='submit']")).click();
		Thread.sleep(2000);
		WebElement usernamevalid=driver.findElement(By.xpath("//input[@name='email']"));
		usernamevalid.sendKeys("admin@phptravels.com");
		WebElement password=driver.findElement(By.xpath("//input[@name='password']"));
		password.sendKeys("demoadmin");
		driver.findElement(By.xpath("//button[@id='submit']")).click();
		Thread.sleep(2000);

	}

}
