package Admin_Back_End;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Display_of_booking_invoice_Admin {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "D:\\Software Testing\\Selenium chrome\\Chrome Driver\\chromedriver-win32\\chromedriver.exe");		
		WebDriver driver = new ChromeDriver();

		driver.get("https://phptravels.net/admin");
		Thread.sleep(2000);
		driver.manage().window().maximize();
		Thread.sleep(2000);
		WebElement usernamevalid=driver.findElement(By.xpath("//input[@name='email']"));
		usernamevalid.sendKeys("admin@phptravels.com");
		WebElement password=driver.findElement(By.xpath("//input[@name='password']"));
		password.sendKeys("demoadmin");
		driver.findElement(By.xpath("//button[@id='submit']")).click();
		Thread.sleep(2000);
		WebElement Bookings=driver.findElement(By.cssSelector("body > main > header > ul > li:nth-child(11) > a"));
		Bookings.click();
		WebElement Bookingdetails=driver.findElement(By.cssSelector("body > main > section > div.mt-1 > div > div:nth-child(3) > div > div > div > figure > blockquote.blockquote.border-top.my-1.py-3.pb-0 > div > span > a"));
		Bookingdetails.click();

	}

}
