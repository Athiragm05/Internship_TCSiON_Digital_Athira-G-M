package Admin_Back_End;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class Website_Admin {

	public static void main(String[] args) throws Exception {
		
		System.setProperty("webdriver.chrome.driver", "D:\\Software Testing\\Selenium chrome\\Chrome Driver\\chromedriver-win32\\chromedriver.exe");		
		WebDriver driver = new ChromeDriver();

		driver.get("https://phptravels.net/admin");
		Thread.sleep(2000);
		driver.manage().window().maximize();
		Thread.sleep(2000);
		WebElement usernamevalid=driver.findElement(By.xpath("//input[@name='email']"));
		usernamevalid.sendKeys("admin@phptravels.com");
		WebElement password=driver.findElement(By.xpath("//input[@name='password']"));
		password.sendKeys("demoadmin");
		driver.findElement(By.xpath("//button[@id='submit']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/main/header/div[1]/a[2]")).click();
		Thread.sleep(2000);
	       driver.switchTo().defaultContent();
			
			String parentwindow=driver.getWindowHandle();
			Set<String> childwindow=driver.getWindowHandles();
			Iterator<String> i=childwindow.iterator();
			while(i.hasNext())
			{
			String cwindow=i.next();
			if(!parentwindow.equals(cwindow))
			{
				driver.switchTo().window(cwindow);
			}
			}
			System.out.println(driver.getCurrentUrl());
			Thread.sleep(2000);
			driver.quit();
		
		
	}

}
